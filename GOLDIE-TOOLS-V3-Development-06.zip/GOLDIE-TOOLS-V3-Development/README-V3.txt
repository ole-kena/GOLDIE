GOLDIE TOOLS V3 — DEVELOPMENT BUILD 06

This package continues the GOLDIE V2-derived app, retaining the existing HTML/CSS/JS app and supplied brand assets. It includes the XAUUSD journal/backend foundation, MT5 monitor source, Android WebView project, native voice/notification bridge, and a GitHub Actions cloud APK build workflow.

Start here:
- BUILD-06-NOTES.txt: phone-only cloud build instructions and limitations.
- android/: native Android project.
- .github/workflows/android-debug-apk.yml: cloud APK workflow.
- index.html: web app.
- backend/: journal API foundation.
- mt5/: MT5 monitor source (not yet compiled/verified against Exness).

This is a development source package, not a finished or tested APK. Back up the previous build before replacing any deployed version.
