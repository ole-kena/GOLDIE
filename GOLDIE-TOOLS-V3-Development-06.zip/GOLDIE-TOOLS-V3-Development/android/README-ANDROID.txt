GOLDIE TOOLS — ANDROID PROJECT (DEV BUILD 06)

This project wraps the existing GOLDIE web app in an Android WebView and exposes native TextToSpeech and notification channels through GoldieNative.

BUILD LOCALLY
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3
Run: gradle --no-daemon assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk

PHONE-ONLY CLOUD BUILD
A GitHub Actions workflow is included at ../.github/workflows/android-debug-apk.yml. Upload the full project to GitHub, including the hidden .github directory, then run the workflow from the Actions tab. Download the GOLDIE-TOOLS-debug-apk artifact after success.

Package: com.goldie.tools
Version: 3.0.0-dev06
Minimum Android: API 23
Target SDK: 35

LIMITATIONS
- This is source code plus a cloud-build workflow, not a precompiled APK.
- Not yet compiled or tested on a Galaxy A15.
- Background Killzone scheduling and live Exness MT5 integration remain unfinished.
- No master or investor MT5 password is requested or stored.
